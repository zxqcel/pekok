const { EmbedBuilder, ApplicationCommandType } = require("discord.js");
const schema = require("../../schemas/stock");

module.exports = {
  name: "add",
  description: "add pricelist to database.",
  cooldown: 2,
  ownerOnly: true,
  type: ApplicationCommandType.ChatInput,
  default_member_permissions: "Administrator", // permission required
  options: [
    {
      name: "price",
      description: "add pricelist to database.",
      type: 1,
      options: [
        {
          name: "kode",
          description: "Code product",
          type: 3,
          required: true,
        },
        {
          name: "name",
          description: "Name product",
          type: 3,
          required: true,
        },
        {
          name: "price",
          description: "wl price",
          type: 10,
          required: true,
        },
        {
          name: "role",
          description: "Role",
          type: 8,
          required: true,
        },
      ],
    },
  ],
  run: async (client, interaction) => {
    const kode = interaction.options.getString("kode");
    const desc = interaction.options.getString("name");
    const harga = interaction.options.getNumber("price");
    // const wallet = interaction.options.getNumber("wallet");
    const roles = interaction.options.getRole("role");
    
    try {
      const checkPriceList = await schema.findOne({ code: kode });

      if (checkPriceList) {
        interaction.reply({ content: `Alredy To Use..` });
        return;
      } else {
        await schema
          .create({
            code: kode,
            desc: desc.toUpperCase(),
            harga: harga,
            data: [],
            role: roles.id
          })
          .then((r) => {
            console.log(r);
          });
        await interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor("#313135")
              .setDescription(
                `Berhasil Menambahkan Pricelist **${desc.toUpperCase()}**`
              ),
          ],
          ephemeral: true,
        });
      }

      return;
    } catch (error) {
      client.slash_err(client, interaction, error);
    }
  },
};
