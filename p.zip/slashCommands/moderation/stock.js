const {
  ApplicationCommandType,
  EmbedBuilder,
  ButtonStyle,
  ButtonBuilder,
  ActionRowBuilder,
} = require("discord.js");
const { getAllStocks, soldHistory } = require("../../handlers/handlerStock");
const { toggleButtonStatus, getButtonStatus } = require('../../functions/buttonStatus');
const SoldHistory = require("../../schemas/sold");

module.exports = {
  name: "stock",
  description: "Check bot's stock.",
  usage: "",
  category: "",
  userPerms: [""],
  botPerms: [""],
  cooldown: 30,
  guildOnly: false,
  ownerOnly: true,
  toggleOff: false,
  nsfwOnly: false,
  maintenance: false,
  type: ApplicationCommandType.ChatInput,
  run: async (client, interaction) => {
    try {
      const channel = client.channels.cache.get(process.env.IDSTOCK);
      if (!channel) return;

      const allStocks = await getAllStocks();
      const soldout = await SoldHistory.findOne({});
        if (!soldout) {
          SoldHistory.create({
            sold: 0,
          });
          return;
        } else if (allStocks.length <= 0) {
        await interaction.reply("No stocks available.");
        return;
      } else {
        interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor("White")
              .setDescription(
                `Silahkan ke channel <#${process.env.IDSTOCK}>, Jika ingin melihat realtime stock!`
              ),
          ],
          ephemeral: true,
        });
        
        const masg = await channel.send({
          embeds: [
            new EmbedBuilder()
            .setColor("White")
              .setDescription(`Waiting sec....`),
          ],
        });

        setInterval(async () => {
        const setUserButton = new ButtonBuilder()
          .setCustomId("modal_setuser")
          .setEmoji(getButtonStatus() ? process.env.EMOJI_MAINTENANCE_BUTTON : process.env.SET_GROWID_EMOJI)
          .setLabel(getButtonStatus() ? 'Maintenance' : 'Set GrowID')
          .setStyle(ButtonStyle.Success)
          .setDisabled(getButtonStatus());

        const balanceButton = new ButtonBuilder()
          .setCustomId("check_bal")
          .setEmoji(getButtonStatus() ? process.env.EMOJI_MAINTENANCE_BUTTON : process.env.CHECK_BALANCE_EMOJI)
          .setLabel(getButtonStatus() ? 'Maintenance' : 'Check Balance')
          .setStyle(ButtonStyle.Success)
          .setDisabled(getButtonStatus());

        const buyButton = new ButtonBuilder()
          .setCustomId("modal_buy")
          .setEmoji(getButtonStatus() ? process.env.EMOJI_MAINTENANCE_BUTTON : process.env.BUY_EMOJI)
          .setLabel(getButtonStatus() ? 'Maintenance' : 'Buy')
          .setStyle(ButtonStyle.Success)
          .setDisabled(getButtonStatus());

        const depositButton = new ButtonBuilder()
          .setCustomId("deposit_info")
          .setEmoji(getButtonStatus() ? process.env.EMOJI_MAINTENANCE_BUTTON : process.env.DEPOSIT_EMOJI)
          .setLabel(getButtonStatus() ? 'Maintenance' : 'Deposit')
          .setStyle(ButtonStyle.Success)
          .setDisabled(getButtonStatus());

        const howtoButton = new ButtonBuilder()
          .setCustomId("howToBuy_info")
          .setEmoji(getButtonStatus() ? process.env.EMOJI_MAINTENANCE_BUTTON : process.env.HOW_TO_BUY_EMOJI)
          .setLabel(getButtonStatus() ? 'Maintenance' : 'How To Buy')
          .setStyle(ButtonStyle.Success)
          .setDisabled(getButtonStatus());

        const buttonRow = new ActionRowBuilder().addComponents(
          setUserButton,
          balanceButton,
          buyButton,
          depositButton,
          howtoButton
        );

          // const intervalSoldout = await SoldHistory.findOne({});
          const intervalSoldout = await soldHistory();
          const intervalStock = await getAllStocks();
          const timestamp = Math.floor(Date.now() / 1000); // Mendapatkan stempel waktu Unix saat ini
          const ShopRdp = new EmbedBuilder()
            .setColor("White")
            .setTitle(`**REALTIME STOCK**`)
            .setDescription(
              `Last Update: <t:${timestamp}:R>\n\n${process.env.PANAH} Total Order: **${intervalSoldout}**`
            )
            .setTimestamp()
            .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
            .setFooter({
              text: `Last Update`,
            })
            .setImage(process.env.STORE_BANNER);

          intervalStock
            .map((stock) => {
              ShopRdp.addFields([
                {
                  name: `**<:kanan:1074608684598046750> ${stock.desc.toUpperCase()}**`,
                  value: `${process.env.PANAH} Kode : **${stock.code}**\n${
                    process.env.PANAH
                  } Stok: **${stock.count}**\n${
                    process.env.PANAH
                  } Harga: **${stock.harga.toString()}** ${process.env.WL}\n`,
                  inline: true,
                },
              ]);
            })
            .join("\n");

          masg.edit({ embeds: [ShopRdp], components: [buttonRow] });
        }, 10000);
      }
    } catch (error) {
      client.slash_err(client, interaction, error);
    }
  },
};
