const { ApplicationCommandType, EmbedBuilder } = require("discord.js");
const Stock = require("../../schemas/stock");

module.exports = {
  name: "changename",
  description: "change Name Product.",
  cooldown: 2,
  ownerOnly: true,
  type: ApplicationCommandType.ChatInput,
  default_member_permissions: "Administrator", // permission required
  options: [
    {
      name: "code",
      description: "Input Code Product",
      type: 3,
      required: true,
    },
    {
      name: "name",
      description: "Input New Name",
      type: 3,
      required: true,
    },
  ],
  run: async (client, interaction) => {
    const code = interaction.options.getString("code");
    const name = interaction.options.getString("name").toUpperCase();
    try {
      const stock = await Stock.findOne({ code });
      if (!stock) {
        await interaction.reply({
          content: `Stock with code ${code} not found.`,
          ephemeral: true,
        });
        return;
      }
      stock.desc = name;
      await stock.save();

      await interaction.reply({
        content: `Product name for code ${code} has been updated to ${name}.`,
        ephemeral: true,
      });
    } catch (error) {
      client.slash_err(client, interaction, error);
    }
  },
};
