const { AttachmentBuilder, EmbedBuilder, ApplicationCommandType } = require("discord.js");
const { buyStock } = require("../../handlers/handlerStock");
const user = require("../../schemas/users");
const Stocks = require("../../schemas/stock");
const SoldHistory = require('../../schemas/sold');
const History = require("../../schemas/testimoni");
const fs = require("fs");

module.exports = {
     name: "send",
     description: "send product of the members.",
     cooldown: 2,
     ownerOnly: true,
     type: ApplicationCommandType.ChatInput,
     default_member_permissions: 'Administrator', // permission required
  options: [
    {
      name: "product",
      description: "send product of the members.",
      type: 1,
      options: [
        {
          name: "user",
          description: "The user you want to send product to.",
          type: 6,
          required: true,
        },
        {
          name: "code",
          description: "code product.",
          type: 3,
          required: true,
        },
        {
          name: "amount",
          description: "Amount product to send.",
          type: 4,
          required: true,
        },
      ],
    },
  ],
  run: async (client, interaction) => {
    let player = interaction.options.getUser("user");
    let codeResult = interaction.options.getString("code");
    let numberInput = interaction.options.getInteger("amount");
    const countResult = parseInt(numberInput, 10);

    const users = await user.findOne({ discordid: player.id });
    const stock = await Stocks.findOne({ code: codeResult });

    if (isNaN(countResult) || countResult < 0) {
      await interaction.reply({
        content: "Gunakan bot dengan bijak.",
        ephemeral: true,
      });
    } else if (!users) {
      interaction.reply({
        content: `User Tersebut Belum Melakukan Registrasi, Silahkan Lakukan Registrasi Terlebih Dahulu.`,
        ephemeral: true,
      });
      return;
    } else if (users.jumlah < stock.harga * countResult) {
      interaction.reply({
        content: `${process.env.WL} Kurang ${
          users.jumlah - stock.harga * countResult
        }`,
        ephemeral: true,
      });
      return;
    } else if (stock.data.length < countResult) {
      await interaction.reply({
        content: `Stock Empty For ${codeResult}.`,
        ephemeral: true,
      });
    } else {
      users.jumlah -= stock.harga * countResult;

      const boughtData = await buyStock(codeResult, countResult);
      let stockData = `Your Product Here ${player.username}:\n\n`;

      stockData += `${boughtData.join("\n\n")}`;

      const filePath = `./${countResult}-${stock.desc}.txt`;
      fs.writeFileSync(filePath, stockData);

      const embedSend = new EmbedBuilder()
        .setTitle("Successful Purchase")
        .setDescription(
          `You have purchased **${countResult} ${stock.desc}** for ${
            stock.harga * countResult
          } ${process.env.WL}\nDon't forget to give reps, Thanks.`
        )
        .setColor("#7289DA")
        .setImage(process.env.STORE_BANNER);

      const file = new AttachmentBuilder(filePath);
      await interaction.reply({
        content: "Product data has been sent.",
        ephemeral: true,
      });
      await player.send({ embeds: [embedSend], files: [file] });
      users.save()
      fs.unlinkSync(filePath);

      const member = interaction.guild.members.cache.get(player.id);
      if (!member) return;

      if (member.roles.cache.has(stock.role) === false) {
        await member.roles.add(stock.role);
    }

      IsCount = await History.findOne({ no: { $eq: 0 } });
      if (!IsCount) {
        await History.create({
          no: 0,
          discordid: 1,
          namaplayer: "null",
          typebarang: "null",
          namabarang: "null",
          hargabarang: 1,
          jumlah: 1,
        });
      }
      countsz = await History.aggregate([
        {
          $group: {
            _id: "",
            last: {
              $max: "$no",
            },
          },
        },
      ]);
      const dogshit = new EmbedBuilder()
        .setColor("#0099ff")
        .setTitle(`**#Order Number** : ${countsz[0].last + 1}`)

        .setTimestamp()
        .setImage(process.env.STORE_BANNER)
        .setFooter({ text: "Thanks For Buying" })
        .setDescription(
          `${process.env.TITIK} Member : **${
            "<@" + player.id + ">"
          }**\n${
            process.env.TITIK
          } Kode Produk : **${codeResult.toUpperCase()}** 
              \n${process.env.TITIK} Nama Product **${stock.desc}**\n${
            process.env.TITIK
          } Jumlah Product : **${countResult}**\n${
            process.env.TITIK
          } Harga Product : **${stock.harga * countResult}** ${process.env.WL}`
        );

      await interaction.guild.channels.cache
        .get(process.env.HISTORY_CHANNEL)
        .send({ embeds: [dogshit] });
      dataz = await user.findOne({ discordid: { $eq: player.id } });

      await History.create({
        no: countsz[0].last + 1,
        discordid: player.id,
        namaplayer: dataz.namaplayer,
        typebarang: codeResult.toUpperCase(),
        namabarang: stock.desc,
        hargabarang: stock.harga,
        jumlah: countResult,
      });

      const soldHistory = await SoldHistory.findOne({});
      if (soldHistory) {
        soldHistory.sold += countResult;
        soldHistory.save();
      } else {
        await SoldHistory.create({
          sold: countResult,
        });
      }
    }
  },
};
