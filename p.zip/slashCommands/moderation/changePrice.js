const { ApplicationCommandType, EmbedBuilder } = require("discord.js");
const Stock = require("../../schemas/stock");

module.exports = {
  name: "changeprice",
  description: "change Price Product.",
  cooldown: 2,
  ownerOnly: true,
  type: ApplicationCommandType.ChatInput,
  default_member_permissions: "Administrator", // permission required
  options: [
    {
      name: "code",
      description: "Input Code Product",
      type: 3,
      required: true,
    },
    {
      name: "price",
      description: "Input New Price",
      type: 4,
      required: true,
    },
  ],
  run: async (client, interaction) => {
    const code = interaction.options.getString("code");
    const price = interaction.options.getInteger("price");
    try {
      const stock = await Stock.findOne({ code });
      if (!stock) {
        await interaction.reply({
          content: `Stock with code ${code} not found.`,
          ephemeral: true,
        });
        return;
      }
      stock.harga = price;
      await stock.save();

      await interaction.reply({
        content: `Product price for code ${code} has been updated to ${price}.`,
        ephemeral: true,
      });
    } catch (error) {
      client.slash_err(client, interaction, error);
    }
  },
};
