const { ApplicationCommandType, EmbedBuilder } = require("discord.js");
const { addStock } = require("../../handlers/handlerStock");

module.exports = {
  name: "addstock",
  description: "Restock product",
  usage: "",
  category: "",
  userPerms: [""],
  botPerms: [""],
  cooldown: 5,
  guildOnly: false,
  ownerOnly: true,
  toggleOff: false,
  nsfwOnly: false,
  maintenance: false,
  type: ApplicationCommandType.ChatInput,
  default_member_permissions: "Administrator",
  options: [
    {
      name: "kode",
      description: "kode your product",
      type: 3,
      required: true,
    },
    {
      name: "data",
      description: "license to restock",
      type: 3,
      required: true,
    },
  ],
  run: async (client, interaction) => {
    const kode = interaction.options.getString("kode");
    const data = interaction.options.getString("data");

    const result = await addStock(kode, data);

    if (result.success) {
      await interaction.reply({
      content: `Added stock for ${kode}. Total items: ${result.newCount}.`,
      ephemeral: true
    });
    } else {
      await interaction.reply({ content: `${result.message}`, ephemeral: true });
    }
  },
};
