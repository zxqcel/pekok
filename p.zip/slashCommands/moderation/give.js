const schema = require("../../schemas/users");
const { EmbedBuilder, ApplicationCommandType } = require('discord.js');
module.exports = {
	name: 'give',
	description: "give balance of the members.",
	cooldown: 2,
  ownerOnly: true,
	type: ApplicationCommandType.ChatInput,
	default_member_permissions: 'ManageGuild', // permission required
	options: [
        {
            name: 'balance',
            description: 'give balance to a user.',
            type: 1,
            options: [
                {
                    name: 'user',
                    description: 'The user you want to add balance to.',
                    type: 6,
                    required: true
                },
                {
                    name: 'amount',
                    description: 'The amount you want to add.',
                    type: 4,
                    required: true
                }
            ]
        }
    ],
	run: async (client, interaction) => {
    let user = interaction.options.getUser("user");
    let amount = interaction.options.getInteger("amount");


  const datas = await schema.findOne({
    discordid: { $eq: user.id },
  });

  if (!datas) {
    interaction.reply({
      content: `User tersebut belum registrasi`,
      ephemeral: true,
    });
    return;
  } else {
        
  datas.jumlah += amount * 1;
  datas.total_depo += amount * 1;
  await datas.save();

  const addcoinsEmbed = new EmbedBuilder()
    .setColor("Green")
    .setDescription(
      `You added **${amount} ${process.env.WL} ** in **${
        user.username
      }#${user.discriminator}**`
    );

  await interaction.reply({
    embeds: [addcoinsEmbed],
    ephemeral: true
  });
  }
  },
};
