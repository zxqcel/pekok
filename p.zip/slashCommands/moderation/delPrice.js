const { deleteStock } = require("../../handlers/handlerStock");
const { EmbedBuilder, ApplicationCommandType } = require('discord.js');

module.exports = {
	name: 'delete',
	description: "delete pricelist to database.",
	cooldown: 2,
    ownerOnly: true,
	type: ApplicationCommandType.ChatInput,
	default_member_permissions: 'Administrator', // permission required
	options: [
        {
            name: 'price',
            description: 'delete pricelist to database.',
            type: 1,
            options: [
                {
                    name: 'kode',
                    description: 'kode your product',
                    type: 3,
                    required: true,
                }
            ]
        }
    ],
	run: async (client, interaction) => {
        const code = interaction.options.getString("kode");
        let msg = '';

        const embed = new EmbedBuilder()
        .setColor("LuminousVividPink")
        .setDescription(`Stock for ${code} deleted.`)
        .setFooter({
            text: `Interaction By ${interaction.user.username}`
        })
        .setTimestamp()

        const success = await deleteStock(code);
        if (success) {
            await interaction.reply({ embeds: [embed], ephemeral: true });
            return;
        } else {
            await interaction.reply({ content: `No stock found for ${code}.`, ephemeral: true });
            return;
        }

  },
};