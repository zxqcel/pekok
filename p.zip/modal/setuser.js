const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, InteractionType } = require('discord.js');
const Users = require('../schemas/users');

function setUserModal() {
    const modal = new ModalBuilder()
    .setCustomId('set_user_modal')
    .setTitle('Set User');

    const growIdInput = new TextInputBuilder()
    .setCustomId('growid_input')
    .setLabel('Masukkan Growid')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

    const growIdRow = new ActionRowBuilder().addComponents(growIdInput);
    modal.addComponents(growIdRow);

    return modal;
}

async function handleSetUserModal(interaction){
    if (interaction.customId === 'set_user_modal') {
        const growIdResult = interaction.fields.getTextInputValue('growid_input')

        const datas = await Users.findOne({
            discordid: {$eq: interaction.user.id},
        });
    
        const usernames = await Users.findOne({
          namaplayer: {$eq: growIdResult.toUpperCase()},
        });
    
        if (usernames) {
          interaction.reply({
              content: `[ERROR] \`${growIdResult}\`**, Alredy To Set**`,
              ephemeral: true
            })
        return;
        }
    
        if (!datas) {
          await Users.create({
            discordid: interaction.user.id,
            namaplayer: growIdResult.toUpperCase(),
            total_depo: 0,
            jumlah: 0,
          });
          interaction.reply({
            content: `[SUCCES] \`${growIdResult}\`**, GrowId Has Ben Set!!**`,
            ephemeral: true
          })
        return;
      }
      
      datas.namaplayer = growIdResult.toUpperCase();
      datas.save();
    
      await interaction.reply({ content: `[SUCCES] Replace Growid To: \`${growIdResult}\``, ephemeral: true})
    }
}

module.exports = { setUserModal, handleSetUserModal };