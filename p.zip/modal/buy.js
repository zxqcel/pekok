const {
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  AttachmentBuilder,
  EmbedBuilder,
} = require("discord.js");
const { buyStock } = require("../handlers/handlerStock");
const user = require("../schemas/users");
const Stocks = require("../schemas/stock");
const History = require("../schemas/testimoni");
const SoldHistory = require('../schemas/sold');
const fs = require("fs");

function buyModal() {
  const modal = new ModalBuilder()
    .setCustomId("buy_modal")
    .setTitle("Buy Product");

  const codeInput = new TextInputBuilder()
    .setCustomId("code_input")
    .setLabel("Masukkan Code Product")
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const countInput = new TextInputBuilder()
    .setCustomId("count_input")
    .setLabel("Masukkan Jumlah Product")
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const codeRow = new ActionRowBuilder().addComponents(codeInput);
  const countRow = new ActionRowBuilder().addComponents(countInput);
  modal.addComponents(codeRow, countRow);

  return modal;
}

async function handleBuyModal(interaction) {
  if (interaction.customId === "buy_modal") {
    const codeResult = interaction.fields.getTextInputValue("code_input");
    const numberInput = interaction.fields.getTextInputValue("count_input");
    const countResult = parseInt(numberInput, 10);

    const users = await user.findOne({ discordid: interaction.user.id });
    const stock = await Stocks.findOne({ code: codeResult });

    if (isNaN(countResult) || countResult < 0) {
      await interaction.reply({
        content: "Gunakan bot dengan bijak.",
        ephemeral: true,
      });
    } else if (!users) {
      interaction.reply({
        content: `Anda Belum Melakukan Registrasi, Silahkan Lakukan Registrasi Terlebih Dahulu.`,
        ephemeral: true,
      });
      return;
    } else if (users.jumlah < stock.harga * countResult) {
      interaction.reply({
        content: `${process.env.WL} Kurang ${
          users.jumlah - stock.harga * countResult
        }`,
        ephemeral: true,
      });
      return;
    } else if (stock.data.length < countResult) {
      await interaction.reply({
        content: `Stock Empty For ${codeResult}.`,
        ephemeral: true,
      });
    } else {
      users.jumlah -= stock.harga * countResult;

      const boughtData = await buyStock(codeResult, countResult);
      let stockData = `Your Product Here ${interaction.user.username}:\n\n`;

      stockData += `${boughtData.join("\n\n")}`;

      const filePath = `./${countResult}-${stock.desc}.txt`;
      fs.writeFileSync(filePath, stockData);
      const file = new AttachmentBuilder(filePath);
      
      const embedSend = new EmbedBuilder()
        .setTitle("Successful Purchase")
        .setDescription(
          `You have purchased **${countResult} ${stock.desc}** for ${
            stock.harga * countResult
          } ${process.env.WL}\nDon't forget to give reps, Thanks.`
        )
        .setColor("#7289DA")
        .setImage(process.env.STORE_BANNER);

        await interaction.reply({
          content: "Product has been sent to your DM.",
          ephemeral: true,
        });
        
        await interaction.user.send({ embeds: [embedSend], files: [file] });
        await users.save();
      
      fs.unlinkSync(filePath);

      const member = interaction.guild.members.cache.get(interaction.user.id);
      if (!member) return;

      if (member.roles.cache.has(stock.role) === false) {
        await member.roles.add(stock.role);
    }
      
      IsCount = await History.findOne({ no: { $eq: 0 } });
      if (!IsCount) {
        await History.create({
          no: 0,
          discordid: 1,
          namaplayer: "null",
          typebarang: "null",
          namabarang: "null",
          hargabarang: 1,
          jumlah: 1,
        });
      }
      countsz = await History.aggregate([
        {
          $group: {
            _id: "",
            last: {
              $max: "$no",
            },
          },
        },
      ]);
      const dogshit = new EmbedBuilder()
        .setColor("#0099ff")
        .setTitle(`**#Order Number** : ${countsz[0].last + 1}`)

        .setTimestamp()
        .setImage(process.env.STORE_BANNER)
        .setFooter({ text: "Thanks For Buying" })
        .setDescription(
          `${process.env.TITIK} Member : **${
            "<@" + interaction.user.id + ">"
          }**\n${
            process.env.TITIK
          } Kode Produk : **${codeResult.toUpperCase()}** 
              \n${process.env.TITIK} Nama Product **${stock.desc}**\n${
            process.env.TITIK
          } Jumlah Product : **${countResult}**\n${
            process.env.TITIK
          } Harga Product : **${stock.harga * countResult}** ${process.env.WL}`
        );

      await interaction.guild.channels.cache
        .get(process.env.HISTORY_CHANNEL)
        .send({ embeds: [dogshit] });
      dataz = await user.findOne({ discordid: { $eq: interaction.user.id } });

      await History.create({
        no: countsz[0].last + 1,
        discordid: interaction.user.id,
        namaplayer: dataz.namaplayer,
        typebarang: codeResult.toUpperCase(),
        namabarang: stock.desc,
        hargabarang: stock.harga,
        jumlah: countResult,
      });

      const soldHistory = await SoldHistory.findOne({});
      if (soldHistory) {
        soldHistory.sold += countResult;
        soldHistory.save();
      } else {
        await SoldHistory.create({
          sold: countResult,
        });
      }
  
    }
  }
}

module.exports = { buyModal, handleBuyModal };
