const { EmbedBuilder } = require("discord.js");
const Depo = require("../../schemas/depo");
const schema = require("../../schemas/users");

async function DepositInfo(interaction) {
  try {
    const depo = await Depo.findOne({})
    const data = await schema.findOne({
      discordid: interaction.user.id,
    });

    if (!data) {
        interaction.reply({ content: `Anda Belum Melakukan Registrasi`, ephemeral: true });
      return;
    } else if (!depo) {
        interaction.reply({ content: `Owner Belum Meletakkan World Depo`, ephemeral: true });
      return;
    } else {
    await interaction.reply({
        embeds: [
      new EmbedBuilder()
        .setColor("#313135")
        .setDescription(
          `${process.env.EMOJI_BOT_DEPO} GrowId: ||${depo.bot}||\n${process.env.EMOJI_OWNER_DEPO} Owner: **${depo.owner}**\n${process.env.EMOJI_WORLD_DEPO}World: **${depo.world}**`
        ),
    ],
    ephemeral: true
});
}
} catch (err) {
  await interaction.reply({
    content: "There was an error while executing this command...",
    ephemeral: true,
  });
}
}

module.exports = { DepositInfo };
