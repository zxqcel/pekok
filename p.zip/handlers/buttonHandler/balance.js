const schema = require("../../schemas/users");
const { EmbedBuilder } = require("discord.js");

async function BalanceCheck(interaction) {
  try {
    data = await schema.findOne({
      discordid: interaction.user.id,
    });

    if (!data) {
      interaction.reply({
        content: `Anda Belum Melakukan Registrasi`,
        ephemeral: true,
      });
      return;
    }
  } catch (err) {
    await interaction.reply({
      content: "There was an error while executing this command...",
      ephemeral: true,
    });
  }

  await interaction.reply({
    embeds: [
      new EmbedBuilder()
        .setColor("#313135")
        .setDescription(
          `\`GrowId: ${data.namaplayer}\`\n\`Balance:\` **${data.jumlah} ${process.env.WL}**\n\`Total Depo:\` **${data.total_depo} ${process.env.WL}**`
        ),
    ],
    ephemeral: true,
  });
}

module.exports = { BalanceCheck };
