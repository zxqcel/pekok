const { EmbedBuilder } = require("discord.js");

const howToBuyInfo = async (interaction) => {
  await interaction.reply({
    embeds: [
      new EmbedBuilder()
        .setColor("#313135")
        .setDescription(
          `**1.** Go to the designated channel for instructions: <#${process.env.CHANNEL_TUTORIAL}>\n**2.** Click the **Deposit** button.\n**3.** Set your GrowID by clicking the **Set** button.\n**4.** Once done, proceed to the deposit world and deposit your Wls (Make sure there's a donation bot available).\n**5.** Check your balance by clicking the **Check Balance** button. After that, click the **Buy** button to purchase what you need.`
        ),
    ],
    ephemeral: true,
  });
};
module.exports = { howToBuyInfo };
